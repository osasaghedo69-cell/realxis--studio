import { useEffect } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { HeroSection } from "@/components/sections/HeroSection";
import { AboutSection } from "@/components/sections/AboutSection";
import { PortfolioSection } from "@/components/sections/PortfolioSection";
import { TestimonialsSection } from "@/components/sections/TestimonialsSection";
import { ClientPortalSection } from "@/components/sections/ClientPortalSection";
import { AutomationSection } from "@/components/sections/AutomationSection";
import { CaseStudiesSection } from "@/components/sections/CaseStudiesSection";
import { DevLogSection } from "@/components/sections/DevLogSection";
import { SalesSection } from "@/components/sections/SalesSection";
import { CtaSection } from "@/components/sections/CtaSection";

export default function Index() {
  useEffect(() => {
    // Set dark mode as default
    document.documentElement.classList.add('dark');
  }, []);

  return (
    <div className="min-h-screen bg-secondary text-white dark">
      {/* Parallax background */}
      <div className="parallax-bg"></div>

      <Header />
      
      <main>
        <HeroSection />
        <AboutSection />
        <PortfolioSection />
        <TestimonialsSection />
        <CaseStudiesSection />
        <ClientPortalSection />
        <AutomationSection />
        <DevLogSection />
        <SalesSection />
        <CtaSection />
      </main>
      
      <Footer />
    </div>
  );
}