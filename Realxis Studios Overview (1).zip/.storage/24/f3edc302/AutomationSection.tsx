import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Workflow, 
  CopyCheck, 
  BarChart3,
  Repeat, 
  ArrowRightLeft
} from "lucide-react";

const automationTools = [
  {
    icon: <CopyCheck className="h-10 w-10 text-primary" />,
    title: "Notion Onboarding",
    description: "Streamlined client onboarding with automated welcome messages, documentation, and project setup."
  },
  {
    icon: <BarChart3 className="h-10 w-10 text-primary" />,
    title: "Airtable CRM",
    description: "Comprehensive client tracking with lead source, project stage, and budget management."
  },
  {
    icon: <Repeat className="h-10 w-10 text-primary" />,
    title: "Zapier Automation",
    description: "Automatic weekly updates, milestone reminders, and client communication triggers."
  },
  {
    icon: <CopyCheck className="h-10 w-10 text-primary" />,
    title: "Sprint Automation",
    description: "Game development sprint management with automated task assignment and progress tracking."
  }
];

export function AutomationSection() {
  return (
    <section id="automation" className="py-24 bg-secondary relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-br from-secondary to-black opacity-80"></div>
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/10 rounded-full blur-3xl"></div>
      <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="section-title">Backend Automation</h2>
          <p className="text-white/70 max-w-2xl mx-auto">
            Our intelligent automation systems streamline project management,
            ensuring seamless communication and efficient workflow.
          </p>
        </div>
        
        <div className="max-w-5xl mx-auto">
          <div className="relative mb-16">
            <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-primary to-transparent"></div>
            <div className="flex justify-center">
              <div className="bg-secondary px-6 py-3 rounded-full relative z-10 border border-white/10 shadow-lg shadow-primary/10">
                <div className="flex items-center gap-3">
                  <Workflow size={20} className="text-primary" />
                  <span className="text-white font-semibold">Fully Automated Game Onboarding System</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Flow Chart */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {automationTools.map((tool, idx) => (
              <div key={idx} className="relative">
                {idx < automationTools.length - 1 && (
                  <div className="absolute top-1/2 right-0 transform translate-x-1/2 hidden md:block">
                    <ArrowRightLeft size={24} className="text-primary/50 rotate-90 lg:rotate-0" />
                  </div>
                )}
                
                <Card className="border-white/10 bg-white/5 backdrop-blur-sm hover:bg-white/10 transition-all card-hover">
                  <CardHeader className="pb-2">
                    <div className="mb-3">{tool.icon}</div>
                    <CardTitle className="text-white text-xl">{tool.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-white/70 text-sm">{tool.description}</p>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
          
          {/* Visual Representation */}
          <div className="mt-16 grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white/5 rounded-xl p-6 backdrop-blur-sm border border-white/10">
              <h3 className="text-white text-xl font-semibold mb-4">Client Journey Automation</h3>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-0.5">
                    <span className="text-primary font-medium text-sm">1</span>
                  </div>
                  <div>
                    <p className="text-white font-medium">Initial Contact</p>
                    <p className="text-white/70 text-sm">Client inquiry auto-routed to the appropriate team</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-0.5">
                    <span className="text-primary font-medium text-sm">2</span>
                  </div>
                  <div>
                    <p className="text-white font-medium">Project Setup</p>
                    <p className="text-white/70 text-sm">Automatic workspace creation with templates and resources</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-0.5">
                    <span className="text-primary font-medium text-sm">3</span>
                  </div>
                  <div>
                    <p className="text-white font-medium">Development Cycle</p>
                    <p className="text-white/70 text-sm">Scheduled updates and progress tracking through development</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-0.5">
                    <span className="text-primary font-medium text-sm">4</span>
                  </div>
                  <div>
                    <p className="text-white font-medium">Delivery & Support</p>
                    <p className="text-white/70 text-sm">Final assets delivery and post-launch support automation</p>
                  </div>
                </li>
              </ul>
            </div>
            
            <div className="bg-white/5 rounded-xl overflow-hidden border border-white/10">
              <div className="p-4 bg-primary/10 border-b border-white/10">
                <h3 className="text-white font-semibold">Client Dashboard Preview</h3>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-white/10 rounded-md p-3">
                    <div className="text-white/50 text-xs mb-1">Current Projects</div>
                    <div className="text-white text-lg font-bold">3</div>
                  </div>
                  <div className="bg-white/10 rounded-md p-3">
                    <div className="text-white/50 text-xs mb-1">Total Tasks</div>
                    <div className="text-white text-lg font-bold">42</div>
                  </div>
                  <div className="bg-white/10 rounded-md p-3">
                    <div className="text-white/50 text-xs mb-1">Completed</div>
                    <div className="text-white text-lg font-bold">27</div>
                  </div>
                  <div className="bg-white/10 rounded-md p-3">
                    <div className="text-white/50 text-xs mb-1">In Progress</div>
                    <div className="text-white text-lg font-bold">15</div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-white text-sm">Project Overview</span>
                    <span className="text-primary text-xs">View All</span>
                  </div>
                  <div className="bg-white/10 rounded-md p-3">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-white text-sm">Open World RPG</span>
                      <span className="text-white/50 text-xs">75%</span>
                    </div>
                    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-primary" style={{ width: "75%" }}></div>
                    </div>
                  </div>
                  <div className="bg-white/10 rounded-md p-3">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-white text-sm">FPS Multiplayer</span>
                      <span className="text-white/50 text-xs">90%</span>
                    </div>
                    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-primary" style={{ width: "90%" }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}