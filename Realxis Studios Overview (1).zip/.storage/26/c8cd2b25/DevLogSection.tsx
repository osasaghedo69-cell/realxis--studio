import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  CalendarDays,
  ChevronRight,
  Play,
  Gamepad2,
  Globe,
  Cricket
} from "lucide-react";

const devLogs = [
  {
    id: 1,
    date: "June 15, 2024",
    title: "New Game Reveal – GTA-style Open World",
    description: "We're excited to reveal our latest project – an expansive GTA-style open world game with unprecedented interaction and detail.",
    type: "announcement",
    image: "https://images.unsplash.com/photo-1618035881605-dfe8d7eb387b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    icon: <Globe size={18} />,
    content: `
      <h4>Project Overview</h4>
      <p>After months of secret development, we're thrilled to announce our most ambitious project yet – a GTA-style open world game set in a fictional modern metropolis.</p>
      
      <h4>Key Features</h4>
      <ul>
        <li>Fully explorable urban environment spanning 25 square kilometers</li>
        <li>Dynamic NPC system with over 1000 unique daily routines</li>
        <li>Realistic vehicle physics with 50+ drivable vehicles</li>
        <li>Branching narrative with consequences that shape the game world</li>
      </ul>
      
      <p>Development is currently in the alpha phase, with a planned beta release in Q4 2024.</p>
      
      <div class="video-embed">
        <img src="https://images.unsplash.com/photo-1618035881605-dfe8d7eb387b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80" alt="Game screenshot" class="w-full h-auto rounded-lg">
        <div class="play-button">▶</div>
      </div>
    `
  },
  {
    id: 2,
    date: "May 28, 2024",
    title: "Cricket Simulator Update: AI Bowler Intelligence",
    description: "Our cricket simulation has reached a new level of realism with our advanced AI bowler system that adapts to batsman weaknesses.",
    type: "update",
    image: "https://images.unsplash.com/photo-1531415074968-036ba1b575da?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    icon: <Cricket size={18} />,
    content: `
      <h4>AI Bowler Update</h4>
      <p>We've completely overhauled the bowling AI in our cricket simulator, implementing a machine learning system that studies batsman patterns.</p>
      
      <h4>Technical Highlights</h4>
      <ul>
        <li>Pattern recognition algorithms to identify batsman preferences</li>
        <li>Dynamic difficulty adjustment based on player skill</li>
        <li>20+ distinct bowling styles with realistic physics</li>
        <li>Weather-influenced ball movement for added realism</li>
      </ul>
      
      <h4>Before & After Comparison</h4>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <p class="text-sm text-white/50 mb-1">Before</p>
          <img src="https://images.unsplash.com/photo-1531415074968-036ba1b575da?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&q=80" alt="Before update" class="w-full h-auto rounded-lg">
        </div>
        <div>
          <p class="text-sm text-white/50 mb-1">After</p>
          <img src="https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&q=80" alt="After update" class="w-full h-auto rounded-lg">
        </div>
      </div>
    `
  },
  {
    id: 3,
    date: "April 10, 2024",
    title: "Prototype: Real-Time FPS with Zombie Mode",
    description: "Check out our latest prototype featuring a fast-paced FPS with a unique zombie survival mode utilizing our custom AI behavior system.",
    type: "prototype",
    image: "https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    icon: <Gamepad2 size={18} />,
    content: `
      <h4>Prototype Overview</h4>
      <p>We're excited to share this early look at our FPS zombie survival prototype, showcasing our latest advancements in AI behavior trees and procedural animation.</p>
      
      <h4>Technical Features</h4>
      <ul>
        <li>Advanced zombie pathfinding and obstacle navigation</li>
        <li>Procedural damage system with realistic limb targeting</li>
        <li>Dynamic difficulty scaling based on player performance</li>
        <li>Procedurally generated environments for endless replayability</li>
      </ul>
      
      <div class="video-embed">
        <img src="https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80" alt="Prototype gameplay" class="w-full h-auto rounded-lg">
        <div class="play-button">▶</div>
      </div>
      
      <p>This prototype demonstrates our commitment to pushing the boundaries of AI behavior in game development. We're currently refining the systems based on initial playtesting feedback.</p>
    `
  }
];

export function DevLogSection() {
  const [expandedLog, setExpandedLog] = useState<number | null>(null);

  const toggleExpand = (id: number) => {
    setExpandedLog(expandedLog === id ? null : id);
  };

  return (
    <section id="dev-logs" className="py-24 bg-secondary/90 relative">
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-secondary opacity-80"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="section-title">Development Logs</h2>
          <p className="text-white/70 max-w-2xl mx-auto">
            Follow our journey through game development with behind-the-scenes updates, technical insights, and project reveals.
          </p>
        </div>
        
        {/* Timeline */}
        <div className="max-w-4xl mx-auto">
          {devLogs.map((log) => (
            <div key={log.id} className="mb-12">
              <div 
                className={cn(
                  "bg-white/5 rounded-xl overflow-hidden transition-all duration-300 border",
                  expandedLog === log.id 
                    ? "border-primary/30" 
                    : "border-white/10 hover:border-white/20"
                )}
              >
                <div 
                  className="p-5 cursor-pointer"
                  onClick={() => toggleExpand(log.id)}
                >
                  <div className="flex items-center gap-3 text-primary/80 mb-3">
                    <CalendarDays size={16} />
                    <span className="text-sm">{log.date}</span>
                    <span 
                      className={cn(
                        "text-xs px-2 py-0.5 rounded-full",
                        log.type === "announcement" 
                          ? "bg-blue-500/20 text-blue-400" 
                          : log.type === "update" 
                            ? "bg-green-500/20 text-green-400" 
                            : "bg-yellow-500/20 text-yellow-400"
                      )}
                    >
                      {log.type}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                        {log.icon}
                      </div>
                      <h3 className="font-bold text-xl text-white">{log.title}</h3>
                    </div>
                    <ChevronRight 
                      size={20} 
                      className={cn(
                        "text-white/50 transition-transform",
                        expandedLog === log.id && "rotate-90"
                      )} 
                    />
                  </div>
                  
                  <p className="text-white/70 mt-3">
                    {log.description}
                  </p>
                </div>
                
                {/* Expanded Content */}
                {expandedLog === log.id && (
                  <div className="border-t border-white/10 p-5">
                    <div 
                      className="prose prose-invert max-w-none prose-headings:text-white prose-h4:text-lg prose-p:text-white/70 prose-li:text-white/70 prose-a:text-primary"
                      dangerouslySetInnerHTML={{ __html: log.content }}
                    />
                    
                    <div className="mt-6 flex justify-end">
                      <Button variant="outline" className="bg-white/5 border-white/20 text-white flex items-center gap-2">
                        <Play size={16} />
                        View Full Devlog
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-8">
          <Button className="cta-button">
            View All Development Logs
          </Button>
        </div>
      </div>
    </section>
  );
}