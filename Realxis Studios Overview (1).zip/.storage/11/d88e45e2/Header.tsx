import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navItems = [
  { title: "Home", href: "#hero" },
  { title: "About", href: "#about" },
  { title: "Portfolio", href: "#portfolio" },
  { title: "Testimonials", href: "#testimonials" },
  { title: "Case Studies", href: "#case-studies" },
  { title: "Contact", href: "#cta" },
];

export function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <header className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-4",
      isScrolled ? "bg-secondary/90 backdrop-blur-lg shadow-lg" : "bg-transparent"
    )}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <a href="#" className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 100 100" fill="none">
                <path d="M30 35L50 25L70 35V65L50 75L30 65V35Z" stroke="white" strokeWidth="3" />
                <path d="M50 25V75" stroke="white" strokeWidth="2" />
                <path d="M30 35L70 35" stroke="white" strokeWidth="2" />
                <path d="M30 65L70 65" stroke="white" strokeWidth="2" />
              </svg>
            </div>
            <span className="text-xl font-bold text-white">Realxis</span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <a
                key={item.title}
                href={item.href}
                className="px-4 py-2 text-sm font-medium text-white/90 hover:text-white transition-colors"
              >
                {item.title}
              </a>
            ))}
            <Button className="ml-4 cta-button">Book Demo</Button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-white p-2"
            aria-label="Toggle menu"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        <div className={cn(
          "md:hidden fixed inset-x-0 bg-secondary/95 backdrop-blur-lg transition-all duration-300 ease-in-out",
          isOpen ? "top-16 opacity-100" : "top-[-100%] opacity-0"
        )}>
          <div className="container mx-auto px-4 py-4 flex flex-col gap-2">
            {navItems.map((item) => (
              <a
                key={item.title}
                href={item.href}
                onClick={() => setIsOpen(false)}
                className="px-4 py-3 text-base font-medium text-white/90 hover:text-white border-b border-white/10"
              >
                {item.title}
              </a>
            ))}
            <Button className="mt-4 cta-button">Book Demo</Button>
          </div>
        </div>
      </div>
    </header>
  );
}