import { useState, useEffect, useRef } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";

const videoTestimonials = [
  {
    id: 1,
    client: "John Davis",
    company: "Apex Games",
    thumbnail: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&q=80",
    videoUrl: "https://www.youtube.com/watch?v=K6sHbwqf7lM", // Unreal Engine 5 Demo Video
    youtubeId: "K6sHbwqf7lM",
    quote: "Working with Realxis Studios transformed our concept into a stunning reality. The team's expertise with Unreal Engine is unmatched!"
  },
  {
    id: 2,
    client: "Sarah Johnson",
    company: "Virtual Visions",
    thumbnail: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&q=80",
    videoUrl: "https://www.youtube.com/watch?v=d1ZnM7CH-v4", // Unreal Engine 5 City Demo
    youtubeId: "d1ZnM7CH-v4",
    quote: "The level of detail and performance optimization achieved by Realxis Studios exceeded our expectations on every level."
  },
  {
    id: 3,
    client: "Michael Chen",
    company: "Quantum Interactive",
    thumbnail: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&q=80",
    videoUrl: "https://www.youtube.com/watch?v=2X_EC3jKrWk", // Unreal Engine 5 Gameplay Demo
    youtubeId: "2X_EC3jKrWk",
    quote: "From concept to execution, the team at Realxis demonstrated incredible skill and creativity with our game project."
  },
  {
    id: 4,
    client: "Amanda Lewis",
    company: "Epic Adventures",
    thumbnail: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&q=80",
    videoUrl: "https://www.youtube.com/watch?v=qC5KtatMcUw", // Unreal Engine 5 Character Demo
    youtubeId: "qC5KtatMcUw",
    quote: "The AI systems developed by Realxis Studios gave our game a level of immersion that our players absolutely love."
  }
];

const messageTestimonials = [
  {
    id: 1,
    client: "Robert Park",
    platform: "WhatsApp",
    message: "Just checked the latest build. The gameplay feels amazing now! Thanks for the quick turnaround on those physics issues.",
    date: "May 12, 2024"
  },
  {
    id: 2,
    client: "Lisa Wong",
    platform: "Telegram",
    message: "My team is blown away by the quality of the character animations. Worth every penny of our investment!",
    date: "April 28, 2024"
  },
  {
    id: 3,
    client: "David Miller",
    platform: "Email",
    message: "The game is already exceeding our KPIs since launch. Your optimization work really paid off. Players are loving the smooth experience even on mid-range devices.",
    date: "June 3, 2024"
  },
];

export function TestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const carouselRef = useRef<HTMLDivElement>(null);

  // Auto-scroll functionality
  useEffect(() => {
    if (paused) return;

    const interval = setInterval(() => {
      setActiveIndex((current) => (current + 1) % videoTestimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [paused]);

  const goToPrev = () => {
    setActiveIndex((current) => (current - 1 + videoTestimonials.length) % videoTestimonials.length);
  };

  const goToNext = () => {
    setActiveIndex((current) => (current + 1) % videoTestimonials.length);
  };

  return (
    <section id="testimonials" className="py-24 bg-secondary relative">
      <div className="absolute inset-0 bg-gradient-to-br from-secondary to-black/80 opacity-80"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <h2 className="section-title">Client Testimonials</h2>
          <p className="text-white/70 max-w-2xl mx-auto">
            Don't just take our word for it — hear directly from our clients about their experiences working with Realxis Studios.
          </p>
        </div>

        {/* Video Testimonials */}
        <div 
          className="relative mb-20" 
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
        >
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-2xl font-semibold text-white flex items-center gap-2">
              <Quote size={20} className="text-primary" /> Video Reviews
            </h3>
            <div className="flex gap-2">
              <Button 
                variant="ghost" 
                size="icon" 
                className="rounded-full hover:bg-white/10 text-white"
                onClick={goToPrev}
              >
                <ChevronLeft size={20} />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="rounded-full hover:bg-white/10 text-white"
                onClick={goToNext}
              >
                <ChevronRight size={20} />
              </Button>
            </div>
          </div>

          {/* Carousel */}
          <div 
            ref={carouselRef}
            className="overflow-hidden relative rounded-xl"
          >
            <div 
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${activeIndex * 100}%)` }}
            >
              {videoTestimonials.map((item) => (
                <div 
                  key={item.id} 
                  className="min-w-full"
                >
                  <div className="bg-black/30 backdrop-blur-sm rounded-xl overflow-hidden">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Video Container */}
                      <div className="aspect-video relative">
                        <img
                          src={item.thumbnail}
                          alt={`${item.client} testimonial`}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                          <a 
                            href={item.videoUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="rounded-full h-16 w-16 bg-primary/80 hover:bg-primary text-white flex items-center justify-center transition-all hover:scale-110"
                            onClick={(e) => {
                              e.preventDefault();
                              window.open(item.videoUrl, '_blank');
                            }}
                          >
                            <svg 
                              xmlns="http://www.w3.org/2000/svg" 
                              width="24" 
                              height="24" 
                              viewBox="0 0 24 24" 
                              fill="none" 
                              stroke="currentColor" 
                              strokeWidth="2" 
                              strokeLinecap="round" 
                              strokeLinejoin="round"
                            >
                              <polygon points="6 3 20 12 6 21 6 3" />
                            </svg>
                          </a>
                        </div>
                      </div>

                      {/* Quote */}
                      <div className="p-6 flex flex-col justify-center">
                        <Quote size={40} className="text-primary opacity-30 mb-4" />
                        <blockquote className="text-xl text-white italic mb-6">
                          "{item.quote}"
                        </blockquote>
                        <div>
                          <p className="text-white font-medium text-lg">{item.client}</p>
                          <p className="text-primary">{item.company}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Dots */}
            <div className="flex justify-center mt-4 gap-2">
              {videoTestimonials.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveIndex(idx)}
                  className={cn(
                    "w-2 h-2 rounded-full transition-all",
                    activeIndex === idx ? "bg-primary w-6" : "bg-white/40 hover:bg-white/60"
                  )}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Client Messages */}
        <div>
          <h3 className="text-2xl font-semibold text-white mb-6 flex items-center gap-2">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="20" 
              height="20" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="text-primary"
            >
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
            </svg>
            Client Conversations
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {messageTestimonials.map((item) => (
              <div 
                key={item.id}
                className="bg-white/5 rounded-xl p-5 backdrop-blur-sm hover:bg-white/10 transition-all"
              >
                <div className="flex justify-between items-center mb-4">
                  <span className="text-primary text-sm">{item.platform}</span>
                  <span className="text-white/50 text-xs">{item.date}</span>
                </div>
                <p className="text-white/90 mb-4 text-sm">
                  "{item.message}"
                </p>
                <p className="text-white font-medium">{item.client}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}