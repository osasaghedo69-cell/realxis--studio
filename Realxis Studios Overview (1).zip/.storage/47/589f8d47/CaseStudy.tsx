import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, TrendingUp, Zap, Award } from "lucide-react";
import { cn } from "@/lib/utils";

// Importing the same case studies data
const caseStudies = [
  {
    id: 1,
    title: "GTA-Style Open World",
    client: "Metropolis Games",
    beforeImage: "https://images.unsplash.com/photo-1519669556878-63bdad8a1a49?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    afterImage: "/images/gamedevelopment.jpg",
    description: "Transformed an early prototype with basic mechanics into a fully-realized open world with advanced AI systems, dynamic weather, and a living city ecosystem.",
    fullDescription: `
      <h2>Project Overview</h2>
      <p>Metropolis Games approached us with an ambitious vision: to create a GTA-style open world game that would push the boundaries of what's possible in modern gaming. They had a basic prototype with rudimentary mechanics but needed our expertise to transform it into a living, breathing world that players could get lost in.</p>
      
      <h2>The Challenge</h2>
      <p>The initial prototype suffered from several limitations:</p>
      <ul>
        <li>Basic world with limited interactivity</li>
        <li>Poor performance with frame rates dropping below 30 FPS</li>
        <li>Simplistic AI with predictable patterns</li>
        <li>Small playable area with obvious boundaries</li>
        <li>Limited player engagement mechanics</li>
      </ul>
      
      <h2>Our Approach</h2>
      <p>We assembled a specialized team of Unreal Engine experts to reimagine and rebuild core systems while maintaining the client's original vision. Our approach focused on:</p>
      
      <h3>World Building & Design</h3>
      <p>We expanded the game world by 10x, creating a diverse city landscape with distinct neighborhoods, suburbs, rural areas, and industrial zones. Each area was carefully crafted with its own architectural style, population demographics, and ambient activities.</p>
      
      <h3>Advanced AI Systems</h3>
      <p>We implemented a revolutionary NPC behavior system with 25+ unique daily patterns. Citizens now have jobs, homes, and routines that change based on time of day, weather conditions, and player actions. Law enforcement responds dynamically to player behavior with escalating response levels.</p>
      
      <h3>Technical Optimization</h3>
      <p>We completely overhauled the rendering pipeline and implemented cutting-edge optimization techniques:</p>
      <ul>
        <li>Level of detail (LOD) system for all assets</li>
        <li>Dynamic streaming system for seamless world loading</li>
        <li>Occlusion culling and view frustum optimization</li>
        <li>Multi-threaded physics calculations</li>
      </ul>
      
      <h3>Gameplay Innovation</h3>
      <p>To increase player engagement, we developed:</p>
      <ul>
        <li>A realistic vehicle physics system with 50+ unique vehicle types</li>
        <li>Dynamic weather system affecting gameplay and NPC behavior</li>
        <li>Procedurally generated side missions ensuring endless gameplay</li>
        <li>Consequence-based morality system shaping the game world</li>
      </ul>
      
      <h2>Results</h2>
      <p>Our work transformed the project into a benchmark for open-world game development:</p>
      <ul>
        <li>Performance boost to 120+ FPS on recommended hardware</li>
        <li>Player retention increased by 65% in beta testing</li>
        <li>Average play session length increased from 45 minutes to 2.5 hours</li>
        <li>Project secured additional funding based on early demos</li>
      </ul>
      
      <h2>Technologies Used</h2>
      <p>The project leveraged cutting-edge Unreal Engine 5 features:</p>
      <ul>
        <li>Nanite for virtualized geometry</li>
        <li>Lumen for dynamic global illumination</li>
        <li>Chaos physics system for destruction and vehicle dynamics</li>
        <li>World Partition for open world streaming</li>
        <li>MetaHuman for realistic character creation</li>
      </ul>
    `,
    improvements: [
      { metric: "FPS boost", value: "120+ FPS" },
      { metric: "Player retention", value: "65% increase" },
      { metric: "World size", value: "10x larger" },
      { metric: "NPC behaviors", value: "25+ unique patterns" }
    ],
    features: ["Realistic vehicle physics", "Dynamic time of day", "Procedural side missions", "Streaming world loading"],
    testimonial: {
      quote: "Realxis Studios transformed our basic prototype into something beyond our wildest expectations. The technical improvements alone would have been impressive, but they also brought our world to life in ways we hadn't even imagined.",
      author: "James Wilson",
      position: "Creative Director, Metropolis Games"
    }
  },
  {
    id: 2,
    title: "Cricket Simulator 2024",
    client: "SportsVirtual",
    beforeImage: "https://images.unsplash.com/photo-1531415074968-036ba1b575da?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    afterImage: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    description: "Elevated a basic cricket game into a professional-grade sports simulator with realistic physics, motion-captured animations, and advanced AI opponents.",
    fullDescription: `
      <h2>Project Overview</h2>
      <p>SportsVirtual came to us with a vision to create the most authentic cricket simulation game ever made. Their initial product had basic gameplay but lacked the realism and depth that cricket enthusiasts demanded.</p>
      
      <h2>The Challenge</h2>
      <p>The original game suffered from several limitations:</p>
      <ul>
        <li>Simplistic physics that didn't account for ball spin, weather conditions, or pitch variations</li>
        <li>Generic animations that didn't capture the unique styles of cricket players</li>
        <li>Basic AI that made predictable decisions regardless of match situation</li>
        <li>Limited stadium environments lacking atmosphere and authenticity</li>
      </ul>
      
      <h2>Our Approach</h2>
      <p>We assembled a team that included both Unreal Engine experts and cricket enthusiasts to ensure technical excellence and authentic gameplay:</p>
      
      <h3>Advanced Physics Simulation</h3>
      <p>We developed a sophisticated ball physics system that accounts for:</p>
      <ul>
        <li>Multiple types of spin (off-spin, leg-spin, googly, etc.)</li>
        <li>Weather effects including humidity and air pressure</li>
        <li>Pitch conditions that evolve throughout a match</li>
        <li>Ball deterioration affecting swing and bounce</li>
      </ul>
      
      <h3>Motion Capture & Animation</h3>
      <p>We partnered with professional cricket players to capture over 5,000 unique animations:</p>
      <ul>
        <li>Distinct bowling styles for pace, spin, and medium pace</li>
        <li>Comprehensive batting shots for all game situations</li>
        <li>Fielding movements including diving catches and boundary saves</li>
        <li>Authentic celebrations and reactions</li>
      </ul>
      
      <h3>AI Intelligence</h3>
      <p>We implemented a multi-layered AI system that:</p>
      <ul>
        <li>Analyzes player weaknesses and adjusts strategies accordingly</li>
        <li>Makes decisions based on match situation, including run rate and wickets</li>
        <li>Features 5 difficulty tiers with distinct play styles</li>
        <li>Employs different strategies for different game formats (Test, ODI, T20)</li>
      </ul>
      
      <h3>Stadium & Atmosphere</h3>
      <p>We created 12 meticulously detailed real-world stadiums with:</p>
      <ul>
        <li>Accurate dimensions and layouts</li>
        <li>Dynamic crowd reactions based on game events</li>
        <li>Time-of-day lighting changes</li>
        <li>Weather systems affecting visibility and playing conditions</li>
      </ul>
      
      <h2>Results</h2>
      <p>The game has achieved remarkable success:</p>
      <ul>
        <li>98% physics accuracy verified by cricket experts</li>
        <li>Highest player satisfaction ratings in cricket game history</li>
        <li>Endorsed by international cricket stars</li>
        <li>Selected as the official game of multiple cricket tournaments</li>
      </ul>
      
      <h2>Technologies Used</h2>
      <ul>
        <li>Custom physics system built in Unreal Engine</li>
        <li>Advanced motion capture technology</li>
        <li>Machine learning for AI behavior patterns</li>
        <li>Realistic audio system for authentic stadium sounds</li>
      </ul>
    `,
    improvements: [
      { metric: "Physics accuracy", value: "98% realistic" },
      { metric: "Animation count", value: "5,000+ motions" },
      { metric: "AI difficulty levels", value: "5 tiers" },
      { metric: "Stadium details", value: "12 real venues" }
    ],
    features: ["AI bowler intelligence", "Weather effects on gameplay", "Career progression system", "Real-time commentary"],
    testimonial: {
      quote: "Our cricket simulator has been transformed into the definitive cricket gaming experience. The level of detail and authenticity that Realxis Studios achieved has set a new standard for sports games.",
      author: "Priya Sharma",
      position: "CEO, SportsVirtual"
    }
  },
  {
    id: 3,
    title: "Fantasy RPG Overhaul",
    client: "Mythic Entertainment",
    beforeImage: "https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    afterImage: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    description: "Revitalized an underperforming RPG by implementing next-gen graphics, an engaging quest system, and revolutionary combat mechanics.",
    fullDescription: `
      <h2>Project Overview</h2>
      <p>Mythic Entertainment approached us with a struggling fantasy RPG that had received mixed reviews and was failing to meet player retention goals. They needed a comprehensive overhaul that would transform the game while maintaining its core identity.</p>
      
      <h2>The Challenge</h2>
      <p>The original game had several critical issues:</p>
      <ul>
        <li>Outdated visuals with low-resolution textures</li>
        <li>Linear, predictable storyline with limited player choices</li>
        <li>Repetitive combat system lacking strategic depth</li>
        <li>Limited character progression options</li>
        <li>Short gameplay experience (under 10 hours)</li>
      </ul>
      
      <h2>Our Approach</h2>
      <p>We implemented a full-scale revitalization while preserving the game's world and lore:</p>
      
      <h3>Visual Transformation</h3>
      <p>We completely rebuilt the visual assets:</p>
      <ul>
        <li>All textures upgraded to 4K resolution</li>
        <li>Character models rebuilt with 3-4x polygon count</li>
        <li>New lighting system with dynamic shadows and global illumination</li>
        <li>Weather and time-of-day systems affecting visual presentation</li>
        <li>New particle effects for magic and combat</li>
      </ul>
      
      <h3>Narrative Expansion</h3>
      <p>We reimagined the storytelling approach:</p>
      <ul>
        <li>Branching storylines with meaningful player choices</li>
        <li>Consequence-based narrative where decisions affect the world</li>
        <li>Side quests with depth and connection to main storyline</li>
        <li>New factions with unique storylines and quests</li>
        <li>Full voice acting for all dialogue (over 15,000 lines)</li>
      </ul>
      
      <h3>Combat Revolution</h3>
      <p>We developed a new combat system focused on player skill and strategy:</p>
      <ul>
        <li>Dynamic targeting system</li>
        <li>Combo-based attacks with timing mechanics</li>
        <li>Realistic physics for weapon impacts</li>
        <li>Enemy AI with adaptive tactics</li>
        <li>Spell crafting system with millions of possible combinations</li>
      </ul>
      
      <h3>World Expansion</h3>
      <p>We significantly expanded the game world:</p>
      <ul>
        <li>Three new major regions with distinct biomes</li>
        <li>Procedurally generated dungeons ensuring unique exploration</li>
        <li>Dynamic event system creating emergent gameplay</li>
        <li>New settlements with unique NPCs and quests</li>
      </ul>
      
      <h2>Results</h2>
      <p>The overhaul transformed the game's commercial and critical reception:</p>
      <ul>
        <li>Average review score improved from 6.3/10 to 9.2/10</li>
        <li>Average playtime increased from 8 hours to 35+ hours</li>
        <li>Monthly active users increased by 350%</li>
        <li>DLC sales exceeded projections by 180%</li>
      </ul>
      
      <h2>Technologies Used</h2>
      <ul>
        <li>Unreal Engine 5 with full migration from previous engine</li>
        <li>Nanite for high-detail environments</li>
        <li>Lumen for advanced lighting effects</li>
        <li>MetaHuman for realistic character faces</li>
        <li>Custom procedural generation system</li>
      </ul>
    `,
    improvements: [
      { metric: "Visual fidelity", value: "4K textures" },
      { metric: "Average playtime", value: "35+ hours" },
      { metric: "Combat animations", value: "3x smoother" },
      { metric: "User reviews", value: "9.2/10 average" }
    ],
    features: ["Branching storylines", "Dynamic combat system", "Full voice acting", "Procedural dungeons"],
    testimonial: {
      quote: "Realxis Studios didn't just improve our game – they reimagined what it could be. The player response has been phenomenal, and what was once our struggling title is now our flagship product.",
      author: "Marcus Thompson",
      position: "Game Director, Mythic Entertainment"
    }
  }
];

export default function CaseStudyPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [showBefore, setShowBefore] = useState(false);
  const [caseStudy, setCaseStudy] = useState<any>(null);

  useEffect(() => {
    const studyId = parseInt(id || "1");
    const study = caseStudies.find(s => s.id === studyId);
    
    if (study) {
      setCaseStudy(study);
      // Set page title
      document.title = `${study.title} | Realxis Studios`;
    } else {
      // Redirect to home if case study not found
      navigate("/");
    }
  }, [id, navigate]);

  if (!caseStudy) {
    return <div className="min-h-screen bg-secondary flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-secondary">
      {/* Hero Section */}
      <div className="relative h-96 overflow-hidden">
        <img 
          src={caseStudy.afterImage} 
          alt={caseStudy.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-secondary to-transparent"></div>
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <div className="container mx-auto">
            <Button 
              variant="outline" 
              className="bg-black/30 border-white/20 text-white hover:bg-black/50 mb-4"
              onClick={() => navigate("/#case-studies")}
            >
              <ArrowLeft size={16} className="mr-2" /> Back to Case Studies
            </Button>
            <h1 className="text-4xl font-bold text-white mb-2">{caseStudy.title}</h1>
            <p className="text-primary text-xl">Client: {caseStudy.client}</p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* Before/After Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-6">The Transformation</h2>
          
          <div className="bg-black/30 rounded-xl overflow-hidden">
            <div className="aspect-video relative">
              <img 
                src={showBefore ? caseStudy.beforeImage : caseStudy.afterImage}
                alt={showBefore ? "Before development" : "After development"}
                className="w-full h-full object-cover"
              />
              
              {/* Image Toggle Controls */}
              <div className="absolute bottom-4 left-4 flex">
                <button
                  className={cn(
                    "px-4 py-2 text-sm font-medium transition-colors",
                    !showBefore 
                      ? "bg-primary text-white" 
                      : "bg-white/10 text-white hover:bg-white/20"
                  )}
                  onClick={() => setShowBefore(false)}
                >
                  After
                </button>
                <button
                  className={cn(
                    "px-4 py-2 text-sm font-medium transition-colors",
                    showBefore 
                      ? "bg-primary text-white" 
                      : "bg-white/10 text-white hover:bg-white/20"
                  )}
                  onClick={() => setShowBefore(true)}
                >
                  Before
                </button>
              </div>
              
              {/* Label */}
              <div className="absolute top-4 right-4">
                <Badge variant="secondary" className="bg-black/60 text-white">
                  {showBefore ? "Before" : "After"} Development
                </Badge>
              </div>
            </div>
          </div>
        </div>
        
        {/* Metrics Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-6 flex items-center">
            <TrendingUp size={24} className="text-primary mr-2" /> Success Metrics
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {caseStudy.improvements.map((item: any, idx: number) => (
              <div key={idx} className="bg-black/30 p-6 rounded-xl text-center">
                <div className="text-3xl font-bold text-primary mb-2">{item.value}</div>
                <div className="text-white/70">{item.metric}</div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Features Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-6 flex items-center">
            <Zap size={24} className="text-primary mr-2" /> Key Features
          </h2>
          
          <div className="flex flex-wrap gap-3">
            {caseStudy.features.map((feature: string, idx: number) => (
              <Badge 
                key={idx} 
                variant="outline" 
                className="bg-primary/10 text-primary border-primary/30 text-base py-2 px-4"
              >
                {feature}
              </Badge>
            ))}
          </div>
        </div>
        
        {/* Testimonial Section */}
        {caseStudy.testimonial && (
          <div className="mb-16">
            <div className="bg-primary/10 border border-primary/20 rounded-xl p-8">
              <div className="text-5xl text-primary/20 mb-4">"</div>
              <blockquote className="text-xl text-white/90 italic mb-6">
                {caseStudy.testimonial.quote}
              </blockquote>
              <div>
                <p className="text-white font-medium">{caseStudy.testimonial.author}</p>
                <p className="text-primary">{caseStudy.testimonial.position}</p>
              </div>
            </div>
          </div>
        )}
        
        {/* Full Description */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-6">Project Details</h2>
          
          <div 
            className="prose prose-lg prose-invert max-w-none prose-headings:text-white prose-headings:font-bold prose-p:text-white/80 prose-li:text-white/80"
            dangerouslySetInnerHTML={{ __html: caseStudy.fullDescription }}
          />
        </div>
        
        {/* CTA Section */}
        <div className="bg-black/30 rounded-xl p-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Transform Your Game?</h2>
          <p className="text-white/70 max-w-2xl mx-auto mb-6">
            Let's discuss how Realxis Studios can help elevate your game project to the next level.
          </p>
          <Button 
            size="lg"
            className="bg-primary hover:bg-primary/80 text-white"
            onClick={() => navigate("/#contact")}
          >
            Contact Us Today
          </Button>
        </div>
      </div>
    </div>
  );
}