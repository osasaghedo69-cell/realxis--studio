import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

export default function ClientPortal() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    
    // This is a mock login - in a real app, you would connect to a backend
    setTimeout(() => {
      setLoading(false);
      // For demo purposes, accept any email with password "demo123"
      if (password === "demo123") {
        // Navigate to a dashboard (we'll redirect to home for this demo)
        alert("Login successful! In a real application, you would now see your client dashboard.");
        navigate("/");
      } else {
        setError("Invalid credentials. Please try again. (Hint: Use any email with password 'demo123')");
      }
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-secondary flex flex-col">
      {/* Header */}
      <div className="bg-black/20 p-4 flex items-center">
        <Button 
          variant="ghost" 
          className="text-white hover:bg-white/10"
          onClick={() => navigate("/")}
        >
          <ArrowLeft size={18} className="mr-2" /> Back to Website
        </Button>
      </div>

      {/* Main content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="bg-black/20 backdrop-blur-sm rounded-xl overflow-hidden border border-white/10 shadow-2xl shadow-primary/5 w-full max-w-md p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 100 100" fill="none">
                <path d="M30 35L50 25L70 35V65L50 75L30 65V35Z" stroke="white" strokeWidth="3" />
                <path d="M50 25V75" stroke="white" strokeWidth="2" />
                <path d="M30 35L70 35" stroke="white" strokeWidth="2" />
                <path d="M30 65L70 65" stroke="white" strokeWidth="2" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold text-white">Realxis Client Portal</h1>
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/30 text-red-400 px-4 py-3 rounded mb-6">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white">Email Address</Label>
              <Input 
                id="email" 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="your.email@company.com"
                className="bg-white/5 border-white/10 text-white"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="password" className="text-white">Password</Label>
                <a href="#" className="text-primary text-sm hover:underline">Forgot password?</a>
              </div>
              <Input 
                id="password" 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                placeholder="••••••••"
                className="bg-white/5 border-white/10 text-white"
              />
            </div>

            <div className="pt-2">
              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-primary/80 text-white"
                disabled={loading}
              >
                {loading ? "Logging in..." : "Log in to Portal"}
              </Button>
            </div>
          </form>

          <div className="mt-8 pt-6 border-t border-white/10 text-center">
            <p className="text-white/60 text-sm">
              Need help? Contact <a href="mailto:support@realxisstudios.com" className="text-primary hover:underline">support@realxisstudios.com</a>
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-black/20 p-4 text-center">
        <p className="text-white/40 text-sm">
          © {new Date().getFullYear()} Realxis Studios. All rights reserved.
        </p>
      </div>
    </div>
  );
}