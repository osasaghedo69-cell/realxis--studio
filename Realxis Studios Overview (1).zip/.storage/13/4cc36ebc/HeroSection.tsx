import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronDown, PlayCircle, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

export function HeroSection() {
  const [isLoaded, setIsLoaded] = useState(false);
  
  useEffect(() => {
    setIsLoaded(true);
  }, []);
  
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-secondary"
    >
      {/* Video Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-secondary/70 z-10"></div>
        <video
          className="w-full h-full object-cover"
          autoPlay
          muted
          loop
          playsInline
          poster="/video-poster.jpg"
        >
          <source src="https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-a-city-11759-large.mp4" type="video/mp4" />
        </video>
      </div>
      
      {/* Purple Glow Effects */}
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/20 rounded-full filter blur-[100px]"></div>
      <div className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-indigo-600/20 rounded-full filter blur-[80px]"></div>
      
      <div className="container mx-auto px-4 z-10 text-center py-24 mt-16">
        <div className={cn(
          "space-y-8 max-w-4xl mx-auto transition-all duration-1000",
          isLoaded ? "opacity-100" : "opacity-0 translate-y-8"
        )}>
          <div className="inline-block rounded-full bg-white/10 backdrop-blur-sm px-4 py-1.5 mb-6">
            <span className="text-sm font-medium text-white flex items-center gap-2">
              <Sparkles size={16} className="text-primary" />
              Unreal Engine Game Development Specialists
            </span>
          </div>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight">
            We Bring <span className="text-gradient">Unreal Ideas</span> to Life
          </h1>
          
          <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto">
            Premium game development studio specializing in Unreal Engine, 
            creating immersive and engaging gaming experiences from concept to launch.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
            <Button className="cta-button" size="lg">
              Book Demo
            </Button>
            <Button variant="outline" size="lg" className="bg-white/5 border-white/20 text-white hover:bg-white/10 flex items-center gap-2">
              <PlayCircle size={20} />
              Watch Showcase
            </Button>
            <Button variant="ghost" size="lg" className="text-white hover:bg-white/10 flex items-center gap-2">
              Request Prototype
            </Button>
          </div>
        </div>
        
        <a
          href="#about"
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center justify-center text-white/70 hover:text-white transition-colors"
          aria-label="Scroll down"
        >
          <span className="text-sm mb-2">Discover More</span>
          <ChevronDown size={24} className="animate-bounce" />
        </a>
      </div>
    </section>
  );
}