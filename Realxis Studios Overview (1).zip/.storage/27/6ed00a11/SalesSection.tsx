import { 
  BarChart3,
  ArrowUpRight,
  Users,
  AlertCircle,
  CheckCircle,
  DollarSign
} from "lucide-react";

export function SalesSection() {
  return (
    <section id="sales-dashboard" className="py-24 bg-secondary relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-black to-secondary opacity-80"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="section-title">Project Dashboard</h2>
          <p className="text-white/70 max-w-2xl mx-auto">
            Get a glimpse of our operational excellence with our project management dashboard, showing how we track and deliver game projects.
          </p>
        </div>
        
        <div className="max-w-6xl mx-auto">
          <div className="bg-black/30 backdrop-blur-sm rounded-xl overflow-hidden border border-white/10 shadow-xl">
            {/* Dashboard Header */}
            <div className="bg-secondary p-4 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BarChart3 size={20} className="text-primary" />
                <h3 className="text-white font-medium">Projects Dashboard</h3>
              </div>
              <div className="text-white/50 text-sm">Last updated: Today, 10:45 AM</div>
            </div>
            
            {/* Dashboard Content */}
            <div className="p-6">
              {/* Stat Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div className="bg-white/5 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-white/70 text-sm">Active Leads</div>
                    <div className="h-8 w-8 rounded-full bg-blue-500/20 flex items-center justify-center">
                      <Users size={16} className="text-blue-400" />
                    </div>
                  </div>
                  <div className="flex items-end gap-2">
                    <div className="text-white text-2xl font-bold">24</div>
                    <div className="text-green-400 text-xs flex items-center">
                      <ArrowUpRight size={12} />
                      12% 
                      <span className="text-white/50 ml-1">vs last month</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white/5 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-white/70 text-sm">Active Projects</div>
                    <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                      <CheckCircle size={16} className="text-primary" />
                    </div>
                  </div>
                  <div className="flex items-end gap-2">
                    <div className="text-white text-2xl font-bold">8</div>
                    <div className="text-green-400 text-xs flex items-center">
                      <ArrowUpRight size={12} />
                      3% 
                      <span className="text-white/50 ml-1">vs last month</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white/5 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-white/70 text-sm">Bug Reports</div>
                    <div className="h-8 w-8 rounded-full bg-yellow-500/20 flex items-center justify-center">
                      <AlertCircle size={16} className="text-yellow-400" />
                    </div>
                  </div>
                  <div className="flex items-end gap-2">
                    <div className="text-white text-2xl font-bold">7</div>
                    <div className="text-green-400 text-xs flex items-center">
                      <ArrowUpRight size={12} className="rotate-180" />
                      15% 
                      <span className="text-white/50 ml-1">vs last month</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white/5 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-white/70 text-sm">Revenue</div>
                    <div className="h-8 w-8 rounded-full bg-green-500/20 flex items-center justify-center">
                      <DollarSign size={16} className="text-green-400" />
                    </div>
                  </div>
                  <div className="flex items-end gap-2">
                    <div className="text-white text-2xl font-bold">$142K</div>
                    <div className="text-green-400 text-xs flex items-center">
                      <ArrowUpRight size={12} />
                      18% 
                      <span className="text-white/50 ml-1">vs last month</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Project Status Section */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <h4 className="text-white font-medium mb-4">Project Status Overview</h4>
                  <div className="bg-white/5 rounded-lg overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-white/5">
                            <th className="text-left text-white/70 text-xs uppercase tracking-wider px-4 py-3">Project</th>
                            <th className="text-left text-white/70 text-xs uppercase tracking-wider px-4 py-3">Client</th>
                            <th className="text-left text-white/70 text-xs uppercase tracking-wider px-4 py-3">Status</th>
                            <th className="text-left text-white/70 text-xs uppercase tracking-wider px-4 py-3">Team</th>
                            <th className="text-left text-white/70 text-xs uppercase tracking-wider px-4 py-3">Progress</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          <tr className="hover:bg-white/5">
                            <td className="px-4 py-3 text-white">GTA-Style Open World</td>
                            <td className="px-4 py-3 text-white/70">Metropolis Games</td>
                            <td className="px-4 py-3">
                              <span className="px-2 py-1 text-xs rounded-full bg-blue-500/20 text-blue-400">In Progress</span>
                            </td>
                            <td className="px-4 py-3 text-white/70">8 members</td>
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-2">
                                <div className="w-16 h-1.5 bg-white/10 rounded-full overflow-hidden">
                                  <div className="h-full bg-primary" style={{ width: "45%" }}></div>
                                </div>
                                <span className="text-white/70 text-xs">45%</span>
                              </div>
                            </td>
                          </tr>
                          <tr className="hover:bg-white/5">
                            <td className="px-4 py-3 text-white">FPS Multiplayer</td>
                            <td className="px-4 py-3 text-white/70">TechnoShooter</td>
                            <td className="px-4 py-3">
                              <span className="px-2 py-1 text-xs rounded-full bg-yellow-500/20 text-yellow-400">Review</span>
                            </td>
                            <td className="px-4 py-3 text-white/70">5 members</td>
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-2">
                                <div className="w-16 h-1.5 bg-white/10 rounded-full overflow-hidden">
                                  <div className="h-full bg-primary" style={{ width: "90%" }}></div>
                                </div>
                                <span className="text-white/70 text-xs">90%</span>
                              </div>
                            </td>
                          </tr>
                          <tr className="hover:bg-white/5">
                            <td className="px-4 py-3 text-white">Cricket Simulator</td>
                            <td className="px-4 py-3 text-white/70">SportsVirtual</td>
                            <td className="px-4 py-3">
                              <span className="px-2 py-1 text-xs rounded-full bg-green-500/20 text-green-400">Complete</span>
                            </td>
                            <td className="px-4 py-3 text-white/70">6 members</td>
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-2">
                                <div className="w-16 h-1.5 bg-white/10 rounded-full overflow-hidden">
                                  <div className="h-full bg-green-500" style={{ width: "100%" }}></div>
                                </div>
                                <span className="text-white/70 text-xs">100%</span>
                              </div>
                            </td>
                          </tr>
                          <tr className="hover:bg-white/5">
                            <td className="px-4 py-3 text-white">Fantasy RPG</td>
                            <td className="px-4 py-3 text-white/70">Mythic Ent.</td>
                            <td className="px-4 py-3">
                              <span className="px-2 py-1 text-xs rounded-full bg-blue-500/20 text-blue-400">In Progress</span>
                            </td>
                            <td className="px-4 py-3 text-white/70">10 members</td>
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-2">
                                <div className="w-16 h-1.5 bg-white/10 rounded-full overflow-hidden">
                                  <div className="h-full bg-primary" style={{ width: "60%" }}></div>
                                </div>
                                <span className="text-white/70 text-xs">60%</span>
                              </div>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-white font-medium mb-4">Team Assignments</h4>
                  <div className="bg-white/5 rounded-lg p-4 space-y-4">
                    <div className="flex justify-between items-center pb-2 border-b border-white/10">
                      <div>
                        <div className="text-white font-medium">Osas Aghedo</div>
                        <div className="text-white/50 text-xs">Project Lead</div>
                      </div>
                      <div className="text-white/70 text-sm">3 Projects</div>
                    </div>
                    <div className="flex justify-between items-center pb-2 border-b border-white/10">
                      <div>
                        <div className="text-white font-medium">Sarah Chen</div>
                        <div className="text-white/50 text-xs">Art Director</div>
                      </div>
                      <div className="text-white/70 text-sm">2 Projects</div>
                    </div>
                    <div className="flex justify-between items-center pb-2 border-b border-white/10">
                      <div>
                        <div className="text-white font-medium">Miguel Rodriguez</div>
                        <div className="text-white/50 text-xs">Lead Designer</div>
                      </div>
                      <div className="text-white/70 text-sm">2 Projects</div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="text-white font-medium">Alex Morgan</div>
                        <div className="text-white/50 text-xs">Technical Director</div>
                      </div>
                      <div className="text-white/70 text-sm">4 Projects</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}