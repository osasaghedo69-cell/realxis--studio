import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Gamepad2, SendHorizonal, Mail, Phone, MapPin } from "lucide-react";

export function CtaSection() {
  return (
    <section id="cta" className="py-24 bg-secondary relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/80 to-black/90 opacity-90"></div>
      
      {/* Purple Glow Effects */}
      <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-primary/10 rounded-full filter blur-[100px]"></div>
      <div className="absolute bottom-1/4 right-1/3 w-64 h-64 bg-indigo-600/10 rounded-full filter blur-[80px]"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="section-title">Ready to Start Your Game Project?</h2>
          <p className="text-white/70 max-w-2xl mx-auto">
            Contact us today to discuss your game concept and discover how Realxis Studios can bring your vision to life with our Unreal Engine expertise.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Form */}
          <div className="bg-black/30 backdrop-blur-sm rounded-xl overflow-hidden border border-white/10 p-6">
            <div className="flex items-center gap-3 mb-6">
              <Gamepad2 size={24} className="text-primary" />
              <h3 className="text-2xl font-bold text-white">Get in Touch</h3>
            </div>
            
            <form className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-white/70 text-sm mb-2">Your Name</label>
                  <Input 
                    id="name" 
                    placeholder="Enter your name" 
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/40 focus:border-primary"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-white/70 text-sm mb-2">Email Address</label>
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="Enter your email" 
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/40 focus:border-primary"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="project" className="block text-white/70 text-sm mb-2">Project Type</label>
                <select 
                  id="project" 
                  className="w-full bg-white/5 border border-white/10 text-white rounded-md h-10 px-3 focus:border-primary outline-none"
                >
                  <option value="" className="bg-secondary">Select project type</option>
                  <option value="fps" className="bg-secondary">FPS Game</option>
                  <option value="rpg" className="bg-secondary">RPG Game</option>
                  <option value="open-world" className="bg-secondary">Open World</option>
                  <option value="sports" className="bg-secondary">Sports Game</option>
                  <option value="other" className="bg-secondary">Other</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="message" className="block text-white/70 text-sm mb-2">Project Details</label>
                <Textarea 
                  id="message" 
                  placeholder="Tell us about your game concept..." 
                  rows={4}
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/40 focus:border-primary resize-none"
                />
              </div>
              
              <Button className="cta-button w-full" size="lg">
                <SendHorizonal size={18} className="mr-2" />
                Submit Request
              </Button>
            </form>
          </div>
          
          {/* Info Card */}
          <div className="flex flex-col justify-between">
            <div>
              <h3 className="text-2xl font-bold text-white mb-6">Why Choose Realxis Studios?</h3>
              <ul className="space-y-4 mb-8">
                <li className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-0.5">
                    <div className="w-2 h-2 rounded-full bg-primary"></div>
                  </div>
                  <div>
                    <h4 className="text-white font-medium">Unreal Engine Specialists</h4>
                    <p className="text-white/70">We focus exclusively on Unreal Engine, giving you the highest level of specialized expertise.</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-0.5">
                    <div className="w-2 h-2 rounded-full bg-primary"></div>
                  </div>
                  <div>
                    <h4 className="text-white font-medium">End-to-End Development</h4>
                    <p className="text-white/70">From concept to launch, we handle every aspect of your game development journey.</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-0.5">
                    <div className="w-2 h-2 rounded-full bg-primary"></div>
                  </div>
                  <div>
                    <h4 className="text-white font-medium">Transparent Process</h4>
                    <p className="text-white/70">Our client portal keeps you informed and involved at every stage of development.</p>
                  </div>
                </li>
              </ul>
            </div>
            
            <div className="mt-8 bg-black/30 backdrop-blur-sm rounded-xl overflow-hidden border border-white/10 p-6">
              <h4 className="text-white font-bold mb-4">Contact Information</h4>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                    <Mail size={18} className="text-primary" />
                  </div>
                  <div>
                    <div className="text-white/50 text-xs">Email</div>
                    <a href="mailto:support@realxis.com" className="text-white hover:text-primary transition-colors">
                      support@realxis.com
                    </a>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                    <Phone size={18} className="text-primary" />
                  </div>
                  <div>
                    <div className="text-white/50 text-xs">Phone</div>
                    <a href="tel:+11234567890" className="text-white hover:text-primary transition-colors">
                      +1 (123) 456-7890
                    </a>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                    <MapPin size={18} className="text-primary" />
                  </div>
                  <div>
                    <div className="text-white/50 text-xs">Website</div>
                    <a href="https://realxis.com" className="text-white hover:text-primary transition-colors">
                      www.realxis.com
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="text-center mt-16">
          <div className="inline-block rounded-full bg-white/10 backdrop-blur-sm px-6 py-3">
            <span className="text-sm font-medium text-white">Start your journey with Realxis Studios today</span>
          </div>
        </div>
      </div>
    </section>
  );
}