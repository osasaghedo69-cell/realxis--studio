import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, TrendingUp, Zap, Award } from "lucide-react";

const caseStudies = [
  {
    id: 1,
    title: "GTA-Style Open World",
    client: "Metropolis Games",
    beforeImage: "https://images.unsplash.com/photo-1519669556878-63bdad8a1a49?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    afterImage: "/images/gamedevelopment.jpg",
    description: "Transformed an early prototype with basic mechanics into a fully-realized open world with advanced AI systems, dynamic weather, and a living city ecosystem.",
    improvements: [
      { metric: "FPS boost", value: "120+ FPS" },
      { metric: "Player retention", value: "65% increase" },
      { metric: "World size", value: "10x larger" },
      { metric: "NPC behaviors", value: "25+ unique patterns" }
    ],
    features: ["Realistic vehicle physics", "Dynamic time of day", "Procedural side missions", "Streaming world loading"]
  },
  {
    id: 2,
    title: "Cricket Simulator 2024",
    client: "SportsVirtual",
    beforeImage: "https://images.unsplash.com/photo-1531415074968-036ba1b575da?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    afterImage: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    description: "Elevated a basic cricket game into a professional-grade sports simulator with realistic physics, motion-captured animations, and advanced AI opponents.",
    improvements: [
      { metric: "Physics accuracy", value: "98% realistic" },
      { metric: "Animation count", value: "5,000+ motions" },
      { metric: "AI difficulty levels", value: "5 tiers" },
      { metric: "Stadium details", value: "12 real venues" }
    ],
    features: ["AI bowler intelligence", "Weather effects on gameplay", "Career progression system", "Real-time commentary"]
  },
  {
    id: 3,
    title: "Fantasy RPG Overhaul",
    client: "Mythic Entertainment",
    beforeImage: "https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    afterImage: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
    description: "Revitalized an underperforming RPG by implementing next-gen graphics, an engaging quest system, and revolutionary combat mechanics.",
    improvements: [
      { metric: "Visual fidelity", value: "4K textures" },
      { metric: "Average playtime", value: "35+ hours" },
      { metric: "Combat animations", value: "3x smoother" },
      { metric: "User reviews", value: "9.2/10 average" }
    ],
    features: ["Branching storylines", "Dynamic combat system", "Full voice acting", "Procedural dungeons"]
  }
];

export function CaseStudiesSection() {
  const [activeCase, setActiveCase] = useState(caseStudies[0].id);
  const [showBefore, setShowBefore] = useState(false);
  
  const currentCase = caseStudies.find(study => study.id === activeCase) || caseStudies[0];

  return (
    <section id="case-studies" className="py-24 bg-secondary relative">
      <div className="absolute inset-0 bg-gradient-to-tl from-black to-secondary opacity-80"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="section-title">Game Success Stories</h2>
          <p className="text-white/70 max-w-2xl mx-auto">
            See the transformative journeys of our game projects from concept to polished masterpieces.
          </p>
        </div>

        {/* Case Tabs */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-12">
          {caseStudies.map((study) => (
            <button
              key={study.id}
              className={cn(
                "text-left p-4 rounded-xl transition-all",
                study.id === activeCase 
                  ? "bg-primary/20 border border-primary/50" 
                  : "bg-white/5 hover:bg-white/10 border border-transparent"
              )}
              onClick={() => setActiveCase(study.id)}
            >
              <h3 className={cn(
                "text-xl font-bold mb-1",
                study.id === activeCase ? "text-primary" : "text-white"
              )}>
                {study.title}
              </h3>
              <p className="text-white/70 text-sm">Client: {study.client}</p>
            </button>
          ))}
        </div>

        {/* Case Content */}
        <div className="bg-black/30 backdrop-blur-sm rounded-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
            {/* Before/After Images */}
            <div className="relative">
              <div className="aspect-video relative overflow-hidden">
                {/* After Image */}
                <img 
                  src={showBefore ? currentCase.beforeImage : currentCase.afterImage}
                  alt={showBefore ? "Before development" : "After development"}
                  className="w-full h-full object-cover"
                />
                
                {/* Image Toggle Controls */}
                <div className="absolute bottom-4 left-4 flex">
                  <button
                    className={cn(
                      "px-3 py-1.5 text-sm font-medium transition-colors",
                      !showBefore 
                        ? "bg-primary text-white" 
                        : "bg-white/10 text-white hover:bg-white/20"
                    )}
                    onClick={() => setShowBefore(false)}
                  >
                    After
                  </button>
                  <button
                    className={cn(
                      "px-3 py-1.5 text-sm font-medium transition-colors",
                      showBefore 
                        ? "bg-primary text-white" 
                        : "bg-white/10 text-white hover:bg-white/20"
                    )}
                    onClick={() => setShowBefore(true)}
                  >
                    Before
                  </button>
                </div>
                
                {/* Label */}
                <div className="absolute top-4 right-4">
                  <Badge variant="secondary" className="bg-black/60 text-white">
                    {showBefore ? "Before" : "After"} Development
                  </Badge>
                </div>
              </div>
            </div>
            
            {/* Case Details */}
            <div className="p-6 lg:p-8">
              <h3 className="text-2xl font-bold text-white mb-3">{currentCase.title}</h3>
              <p className="text-primary font-medium mb-4">Client: {currentCase.client}</p>
              
              <p className="text-white/80 mb-6">
                {currentCase.description}
              </p>
              
              <div className="mb-6">
                <h4 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                  <TrendingUp size={18} className="text-primary" /> Success Metrics
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {currentCase.improvements.map((item, idx) => (
                    <div key={idx} className="bg-white/5 p-3 rounded-lg">
                      <div className="text-lg font-bold text-white">{item.value}</div>
                      <div className="text-white/60 text-xs">{item.metric}</div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h4 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                  <Zap size={18} className="text-primary" /> Key Features Added
                </h4>
                <div className="flex flex-wrap gap-2">
                  {currentCase.features.map((feature, idx) => (
                    <Badge key={idx} variant="outline" className="bg-primary/10 text-primary border-primary/30">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <Button 
                className="mt-8 flex items-center gap-2"
                onClick={() => window.location.href = `/case-study/${currentCase.id}`}
              >
                View Full Case Study <ArrowRight size={16} />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}