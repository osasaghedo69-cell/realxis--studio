import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Gamepad2, Award, Joystick, Radio, Globe } from "lucide-react";

const categories = [
  { id: "all", name: "All", icon: <Gamepad2 size={16} /> },
  { id: "fps", name: "FPS", icon: <Gamepad2 size={16} /> },
  { id: "rpg", name: "RPG", icon: <Award size={16} /> },
  { id: "cricket", name: "Cricket", icon: <Radio size={16} /> },
  { id: "open-world", name: "Open World", icon: <Globe size={16} /> },
  { id: "prototype", name: "Prototypes", icon: <Joystick size={16} /> },
];

const projects = [
  {
    id: 1,
    title: "Celestial Odyssey",
    category: "rpg",
    thumbnail: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&q=80",
    description: "An epic RPG adventure set in a vast celestial universe with dynamic character progression and immersive storyline.",
    features: ["Open World", "Dynamic Combat", "Character Customization", "Multiplayer"],
    techStack: ["Unreal Engine 5", "Blueprint", "C++", "NVIDIA RTX"]
  },
  {
    id: 2,
    title: "Tactical Strike",
    category: "fps",
    thumbnail: "https://images.unsplash.com/photo-1552346154-21d32810aba3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&q=80",
    description: "A competitive first-person shooter with tactical gameplay elements and strategic team-based objectives.",
    features: ["PvP Multiplayer", "Custom Loadouts", "10+ Maps", "E-Sports Ready"],
    techStack: ["Unreal Engine 5", "C++", "Photon Networking", "FMOD"]
  },
  {
    id: 3,
    title: "Cricket Champions",
    category: "cricket",
    thumbnail: "https://images.unsplash.com/photo-1531415074968-036ba1b575da?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&q=80",
    description: "The most realistic cricket simulation game with professional teams and physics-based gameplay.",
    features: ["AI Bowler", "Career Mode", "Real Teams", "Stadium Builder"],
    techStack: ["Unreal Engine 4", "PhysX", "Blueprint", "AI Behavior Trees"]
  },
  {
    id: 4,
    title: "Freedom Roads",
    category: "open-world",
    thumbnail: "https://images.unsplash.com/photo-1511512578047-dfb367046420?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&q=80",
    description: "A vast open-world driving experience with hundreds of miles of roads and dynamic events.",
    features: ["Seamless World", "Vehicle Customization", "Dynamic Weather", "Day-Night Cycle"],
    techStack: ["Unreal Engine 5", "C++", "Nanite", "Lumen"]
  },
  {
    id: 5,
    title: "Zombie Survival",
    category: "prototype",
    thumbnail: "https://images.unsplash.com/photo-1547941126-3d5322b218b0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&q=80",
    description: "A prototype demonstrating advanced zombie AI and survival mechanics in a post-apocalyptic setting.",
    features: ["Crafting System", "Base Building", "Advanced AI", "Procedural Generation"],
    techStack: ["Unreal Engine 5", "Blueprint", "Behavior Trees", "Niagara FX"]
  },
  {
    id: 6,
    title: "Battle Royale Prototype",
    category: "prototype",
    thumbnail: "/images/BattleRoyale.jpg",
    description: "A functional battle royale prototype with core mechanics and matchmaking system.",
    features: ["100 Players", "Shrinking Zone", "Loot System", "Spectator Mode"],
    techStack: ["Unreal Engine 5", "Blueprint", "EOS", "Custom Server"]
  }
];

export function PortfolioSection() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedProject, setSelectedProject] = useState<number | null>(null);

  const filteredProjects = selectedCategory === "all" 
    ? projects 
    : projects.filter(project => project.category === selectedCategory);

  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setSelectedProject(null);
  };

  const handleProjectClick = (projectId: number) => {
    setSelectedProject(projectId === selectedProject ? null : projectId);
  };

  return (
    <section id="portfolio" className="py-24 bg-secondary/90 relative">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-secondary to-black/90 opacity-70"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <h2 className="section-title">Our Game Portfolio</h2>
          <p className="text-white/70 max-w-2xl mx-auto">
            Explore our diverse portfolio of Unreal Engine game projects, showcasing our expertise
            across various genres and gameplay styles.
          </p>
        </div>

        {/* Categories Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              className={cn(
                "flex items-center gap-2",
                selectedCategory === category.id 
                  ? "bg-primary text-white" 
                  : "bg-transparent text-white/80 hover:text-white hover:border-primary"
              )}
              onClick={() => handleCategoryClick(category.id)}
            >
              {category.icon}
              <span>{category.name}</span>
            </Button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <div 
              key={project.id}
              className={cn(
                "rounded-xl overflow-hidden card-hover",
                selectedProject === project.id && "ring-2 ring-primary"
              )}
            >
              <div className="relative aspect-video overflow-hidden">
                <img 
                  src={project.thumbnail}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-4">
                  <h3 className="text-xl font-bold text-white">{project.title}</h3>
                  <p className="text-primary text-sm capitalize">{project.category}</p>
                </div>
              </div>

              <div className="p-4 bg-secondary">
                <p className="text-white/80 text-sm line-clamp-2 mb-3">{project.description}</p>
                <Button
                  variant="ghost"
                  className="text-primary hover:text-primary hover:bg-primary/10 w-full justify-between"
                  onClick={() => handleProjectClick(project.id)}
                >
                  {selectedProject === project.id ? "Hide Details" : "View Details"}
                  <svg
                    className={cn("h-4 w-4 transition-transform", selectedProject === project.id ? "rotate-180" : "")}
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                  >
                    <path
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </Button>
              </div>

              {/* Expanded Details */}
              {selectedProject === project.id && (
                <div className="p-4 bg-secondary border-t border-white/10">
                  <h4 className="font-medium text-white mb-2">Features:</h4>
                  <ul className="grid grid-cols-2 gap-x-2 gap-y-1 mb-4">
                    {project.features.map((feature, idx) => (
                      <li key={idx} className="text-white/70 text-sm flex items-center gap-1">
                        <div className="w-1 h-1 rounded-full bg-primary"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <h4 className="font-medium text-white mb-2">Tech Stack:</h4>
                  <div className="flex flex-wrap gap-2">
                    {project.techStack.map((tech, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 bg-white/5 rounded-full text-xs font-medium text-white/80"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button className="cta-button">
            View Full Portfolio
          </Button>
        </div>
      </div>
    </section>
  );
}