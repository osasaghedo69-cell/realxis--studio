import { 
  Mail, 
  Youtube, 
  Twitter, 
  Linkedin, 
  MessageSquareText 
} from "lucide-react";
import { Button } from "@/components/ui/button";

const footerLinks = [
  {
    title: "Quick Links",
    links: [
      { name: "Portfolio", href: "#portfolio" },
      { name: "Services", href: "#services" },
      { name: "Testimonials", href: "#testimonials" },
      { name: "Contact", href: "#cta" },
      { name: "Client Portal", href: "#client-portal" }
    ]
  },
  {
    title: "Resources",
    links: [
      { name: "Game Showcase", href: "#portfolio" },
      { name: "Dev Logs", href: "#dev-logs" },
      { name: "Case Studies", href: "#case-studies" },
      { name: "Success Stories", href: "#case-studies" }
    ]
  }
];

const socialLinks = [
  { icon: <Youtube size={20} />, href: "#", label: "YouTube" },
  { icon: <Twitter size={20} />, href: "#", label: "X (Twitter)" },
  { icon: <MessageSquareText size={20} />, href: "#", label: "Discord" },
  { icon: <Linkedin size={20} />, href: "#", label: "LinkedIn" }
];

export function Footer() {
  return (
    <footer className="bg-secondary pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Column */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 100 100" fill="none">
                  <path d="M30 35L50 25L70 35V65L50 75L30 65V35Z" stroke="white" strokeWidth="3" />
                  <path d="M50 25V75" stroke="white" strokeWidth="2" />
                  <path d="M30 35L70 35" stroke="white" strokeWidth="2" />
                  <path d="M30 65L70 65" stroke="white" strokeWidth="2" />
                </svg>
              </div>
              <span className="text-xl font-bold text-white">Realxis Studios</span>
            </div>
            <p className="text-white/70 text-sm">
              We Bring Unreal Ideas to Life
            </p>
            <div className="flex items-center gap-2 text-white/70">
              <Mail size={18} />
              <a href="mailto:support@realxis.com" className="text-sm hover:text-primary transition-colors">
                support@realxis.com
              </a>
            </div>
            <div className="flex items-center gap-3 pt-2">
              {socialLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.href}
                  aria-label={link.label}
                  className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-primary transition-colors"
                >
                  {link.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Footer Links */}
          {footerLinks.map((column, i) => (
            <div key={i} className="space-y-4">
              <h4 className="text-white font-medium text-lg">{column.title}</h4>
              <ul className="space-y-2">
                {column.links.map((link, j) => (
                  <li key={j}>
                    <a
                      href={link.href}
                      className="text-white/70 hover:text-primary transition-colors text-sm"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Contact Column */}
          <div className="space-y-4">
            <h4 className="text-white font-medium text-lg">Ready to Start?</h4>
            <p className="text-white/70 text-sm">
              Get in touch for a free consultation about your next game project.
            </p>
            <Button className="cta-button w-full">Book Free Consultation</Button>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/10 text-center text-white/50 text-sm">
          <p>Copyright © {new Date().getFullYear()} Realxis Studios. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}