import { useState } from "react";
import { cn } from "@/lib/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Trophy,
  Users,
  Code2,
  Clock,
  CheckCircle2
} from "lucide-react";

const teamMembers = [
  {
    name: "Osas Aghedo",
    role: "CEO & Lead Game Developer",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80",
  },
  {
    name: "Alex Morgan",
    role: "Technical Director",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80",
  },
  {
    name: "Sarah Chen",
    role: "Art Director",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80",
  },
  {
    name: "Miguel Rodriguez",
    role: "Lead Game Designer",
    image: "https://images.unsplash.com/photo-1567515004624-219c11d31f2e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80",
  }
];

const milestones = [
  {
    year: 2018,
    title: "Realxis Studios Founded",
    description: "Started with a small team of 3 passionate game developers"
  },
  {
    year: 2019,
    title: "First Major Client",
    description: "Secured our first major project with a notable indie game publisher"
  },
  {
    year: 2020,
    title: "Team Expansion",
    description: "Grew to 10 full-time developers and launched 5 successful game projects"
  },
  {
    year: 2021,
    title: "Industry Recognition",
    description: "Won Best Indie Game Developer award at GameDev Summit"
  },
  {
    year: 2022,
    title: "International Expansion",
    description: "Established partnerships with studios across Europe and Asia"
  },
  {
    year: 2023,
    title: "Technical Innovation",
    description: "Pioneered new rendering techniques for mobile Unreal Engine games"
  },
  {
    year: 2024,
    title: "100+ Projects Milestone",
    description: "Celebrated completing over 100 successful game development projects"
  }
];

interface StatItemProps {
  icon: React.ReactNode;
  value: string;
  label: string;
}

function StatItem({ icon, value, label }: StatItemProps) {
  return (
    <div className="flex flex-col items-center text-center p-4">
      <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mb-3">
        <div className="text-primary">{icon}</div>
      </div>
      <div className="text-3xl font-bold text-white mb-1">{value}</div>
      <div className="text-white/70 text-sm">{label}</div>
    </div>
  );
}

export function AboutSection() {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <section id="about" className="py-20 bg-secondary relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-radial from-primary/5 to-transparent opacity-50"></div>
      
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-title">About Realxis Studios</h2>
          <p className="text-white/70 max-w-2xl mx-auto">
            We are a premium game development studio specializing in Unreal Engine, 
            dedicated to bringing innovative and immersive gaming experiences to life.
          </p>
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
          <StatItem 
            icon={<Trophy size={24} />}
            value="100+"
            label="Game Projects"
          />
          <StatItem 
            icon={<Users size={24} />}
            value="20+"
            label="Team Members"
          />
          <StatItem 
            icon={<Code2 size={24} />}
            value="5+"
            label="Years Experience"
          />
          <StatItem 
            icon={<CheckCircle2 size={24} />}
            value="98%"
            label="Client Satisfaction"
          />
        </div>
        
        {/* Tabs */}
        <Tabs defaultValue="team" className="w-full">
          <div className="flex justify-center mb-8">
            <TabsList className="bg-secondary border border-white/10">
              <TabsTrigger value="team" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                Our Team
              </TabsTrigger>
              <TabsTrigger value="timeline" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                Our Journey
              </TabsTrigger>
            </TabsList>
          </div>
          
          {/* Team Tab Content */}
          <TabsContent value="team" className="mt-0">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {teamMembers.map((member, index) => (
                <div 
                  key={index}
                  className="relative overflow-hidden rounded-xl card-hover"
                  onMouseEnter={() => setHoveredIndex(index)}
                  onMouseLeave={() => setHoveredIndex(null)}
                >
                  <div className="aspect-[3/4] overflow-hidden">
                    <img 
                      src={member.image} 
                      alt={member.name} 
                      className={cn(
                        "w-full h-full object-cover transition-transform duration-500",
                        hoveredIndex === index ? "scale-110" : "scale-100"
                      )}
                    />
                  </div>
                  <div className={cn(
                    "absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent flex flex-col justify-end p-4 transition-opacity",
                    hoveredIndex === index ? "opacity-100" : "opacity-90"
                  )}>
                    <h4 className="text-xl font-semibold text-white mb-1">{member.name}</h4>
                    <p className="text-primary text-sm">{member.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
          
          {/* Timeline Tab Content */}
          <TabsContent value="timeline" className="mt-0">
            <div className="flex flex-col space-y-0">
              {milestones.map((milestone, index) => (
                <div key={index} className="flex">
                  {/* Timeline line with dot */}
                  <div className="flex flex-col items-center mr-4">
                    <div className="w-4 h-4 rounded-full bg-primary"></div>
                    {index !== milestones.length - 1 && (
                      <div className="w-px h-24 bg-primary/30"></div>
                    )}
                  </div>
                  
                  {/* Content */}
                  <div className="pb-10 flex-1">
                    <div className="text-primary font-bold text-lg mb-1">{milestone.year}</div>
                    <div className="text-white text-xl font-semibold mb-2">{milestone.title}</div>
                    <div className="text-white/70">{milestone.description}</div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}